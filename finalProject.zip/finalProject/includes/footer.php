<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h4 class="title">Information</h4>
                <p><a href="about_us.php" class="footer_link">About Us</a></p>
                <p><a href="contact_us.php" class="footer_link">Contact Us</a></p>
            </div>
            
            <div class="col-md-4">
                <h4 class="title">My Account</h4>
                <p><a href="login.php"  class="footer_link">Login</a></p>
                <p><a href="signup.php" class="footer_link">Sign Up</a></p>
            </div>

            <div class="col-md-4">
                <h4 class="title">Contact Us</h4>
                <p  class="footer_link"><span class="glyphicon glyphicon-phone-alt"></span> : +91-90000-00000</p>
                <p  class="footer_link"><span class="glyphicon glyphicon-envelope"></span> : lifestyle_store@shoppee.com</p>
            </div>

        </div>
    </div> 
</footer>

